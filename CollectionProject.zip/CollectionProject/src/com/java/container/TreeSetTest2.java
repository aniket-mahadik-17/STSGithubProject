package com.java.container;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetTest2 {
	public static void main(String[] args) {
		
		ChemicalElement chemicalElement1 =new ChemicalElement(10,"Neon","Ne",20.180);
		ChemicalElement chemicalElement2=new ChemicalElement(15,"Phos","K",30.974);
		ChemicalElement chemicalElement3=new ChemicalElement(8,"Oxy","o2",15.999);
		ChemicalElement chemicalElement4=new ChemicalElement(20,"cal","Ca",40.078);
		ChemicalElement chemicalElement5=new ChemicalElement(5,"Bor","Br",10.81);
		ChemicalElement chemicalElement6=new ChemicalElement(9,"Fleu","Fl",18.998);
		ChemicalElement chemicalElement7=new ChemicalElement(13,"Alu","Al",26.98154);
		
		
		TreeSet<ChemicalElement> PeriodicTable=new TreeSet<ChemicalElement>();
		System.out.println("container is ready");
		
		System.out.println("adding 1 element...");
		PeriodicTable.add(chemicalElement1);
		
		System.out.println("adding 2 element...");
		PeriodicTable.add(chemicalElement2);
		
		System.out.println("adding 3 element...");
		PeriodicTable.add(chemicalElement3);
		
		System.out.println("adding 4 element...");
		PeriodicTable.add(chemicalElement4);
		
		System.out.println("adding 5 element...");
		PeriodicTable.add(chemicalElement5);
		
		System.out.println("adding 6 element...");
		PeriodicTable.add(chemicalElement6);
		
		System.out.println("adding 7 element...");
		PeriodicTable.add(chemicalElement7);
		
		Iterator<ChemicalElement>numberIterator=PeriodicTable.iterator();
		while (numberIterator.hasNext()) {
			ChemicalElement theElement=numberIterator.next();
			System.out.println("num is "+theElement);
		}
		
		
	}
	
	
	

}
