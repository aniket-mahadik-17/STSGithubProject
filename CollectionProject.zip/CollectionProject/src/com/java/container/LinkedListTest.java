package com.java.container;

import java.util.Iterator;
import java.util.LinkedList;


public class LinkedListTest {
	public static void main(String[] args) {

		Contact c1 = new Contact("Aniket","aniket_mahadik_17");
		Contact c2 = new Contact("Sanket","sanket_k_17");
		Contact c3 = new Contact("Nitin","ni3_bhujbal");
		Contact c4 = new Contact("Akash","akash_s_8605");
		Contact c5 = new Contact("Yogesh","yogesh_0011");
		System.out.println("Content is ready....");
		
		LinkedList<Contact>   myContact = new LinkedList<>();
		System.out.println("Container is ready....");
		
		myContact.add(c1);
		myContact.add(c2); //quantum computer
		myContact.add(c3); 
		myContact.add(c4); 
		myContact.add(c5); 
		System.out.println("Content is added to the container..");
		
		
		Iterator<Contact> contactIterator = myContact.iterator();
		
		while(contactIterator.hasNext()) {
			Contact theContact = contactIterator.next();
			System.out.println("the Log : "+theContact);
		}
		System.out.println("-----------------");
		for (Contact Contact : myContact) {
			System.out.println("the contact : "+Contact);
		}
	}
}



