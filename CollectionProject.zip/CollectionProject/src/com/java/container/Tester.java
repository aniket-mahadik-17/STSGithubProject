package com.java.container;

public class Tester {

	public static void main(String[] args) {
		AnyType<Integer> mi=new AnyType<Integer>
		
		mi.swap();
		mi.print();

	}

}
