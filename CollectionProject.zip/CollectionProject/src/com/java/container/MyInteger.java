package com.java.container;

public class MyInteger {

}
