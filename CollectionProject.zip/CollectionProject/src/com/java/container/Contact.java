package com.java.container;

public class Contact {
	private String who; //aniket
	private String instaid; // instagram id
	
	public Contact(String who, String instaid) {
		super();
		this.who = who;
		this.instaid = instaid;
		
		
	}

	@Override
	public String toString() {
		return "Contact [who=" + who + ", instaid=" + instaid + "]";
	}

}
