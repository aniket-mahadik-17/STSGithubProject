package com.java.container;

import java.util.Iterator;
import java.util.TreeSet;


public class TreeSetTest {
	public static void main(String[] args) {
		

		TreeSet<Integer> myNumberSet=new TreeSet<Integer>();
		
		System.out.println("container created");
		System.out.println("add first element");
		myNumberSet.add(10);
		System.out.println("add second element");
		myNumberSet.add(15);
		myNumberSet.add(5);
		myNumberSet.add(13);
		myNumberSet.add(8);
		myNumberSet.add(9);
		System.out.println("add all element");
		
		System.out.println("content is added to the container");
		
		Iterator<Integer> numberIterator=myNumberSet.iterator();
		while (numberIterator.hasNext())
		{
			int num=numberIterator.next();
			System.out.println("the number element is..."+num);
		}
	}
}
	
	
	
	

 
