class Tester {
	public static void main(String[] args) {
		MyInteger mi=new MyInteger (10,20);
		mi.swap();
		mi.print();
		
		MyFloat mf=new MyFloat(10.5f,10.5f);
		mf.swap();
		mf.print();
		
		MyString st=new MyString("ok","nok");
		st.swap();
		st.print();
	}
		
}

public class MyInteger{
	private int x;
	private int y;
	
	public MyInteger(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}
	void swap()
	{
		System.out.println("Swapping....");
		int temp=x;
		x=y;
		y=temp;
	}
	void print(){
		System.out.println("x "+x);
		System.out.println("y "+y);
	}

	class MyFloat{
	private float x;
	private float y;
	
	
	
	public MyFloat(float x, float y) {
		super();
		this.x = x;
		this.y = y;
	}
	void swap()
	{
		System.out.println("Swapping....");
		float temp=x;
		x=y;
		y=temp;
	}
	void print(){
		System.out.println("x "+x);
		System.out.println("y "+y);
	}
	
}

class MyString{
	private String x;
	private String y;
	
	
	public MyString(String x, String y) {
		super();
		this.x = x;
		this.y = y;
	}
	void swap()
	{
		System.out.println("Swapping....");
		String temp=x;
		x=y;
		y=temp;
	}
	void print(){
		System.out.println("x "+x);
		System.out.println("y "+y);
	}
	
	
}

