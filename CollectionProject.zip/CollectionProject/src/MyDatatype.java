
public class MyDatatype {
	public static void main(String[] args) {
		MyInteger mi=new MyInteger (10,20);
		mi.swap();
		mi.print();
		
		MyFloat mf=new MyFloat(10.5f,10.5f);
		mf.swap();
		mf.print();
	}
		
}

public class {
	private int x;
	private int y;
	
	public MyInteger(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}
	void swap()
	{
		System.out.println("Swapping....");
		int temp=x;
		x=y;
		y=temp;
	}
	void print(){
		System.out.println("x "+x);
		System.out.println("y "+y);
	}
	
}

public class MyFloat{
	private float x;
	private float y;
	
	
	
	public MyFloat(float x, float y) {
		super();
		this.x = x;
		this.y = y;
	}
	void swap()
	{
		System.out.println("Swapping....");
		float temp=x;
		x=y;
		y=temp;
	}
	void print(){
		System.out.println("x "+x);
		System.out.println("y "+y);
	}
	
}




